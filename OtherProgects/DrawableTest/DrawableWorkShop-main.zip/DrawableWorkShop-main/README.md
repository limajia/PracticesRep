# DrawableWorkShop
WorkShop for custom drawable in Android

配合文章：

* [三思系列：重新认识Drawable](https://juejin.cn/post/6924240361317466125)
* [迟来的续集--Drawable+Animator，将优雅进行到底](https://juejin.cn/post/7155690991721119781) 